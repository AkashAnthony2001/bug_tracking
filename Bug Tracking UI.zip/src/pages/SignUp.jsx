import * as React from 'react';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { Select, MenuItem, InputLabel, FormControl } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import apiService from '../services/apiService'
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom'
import { useEffect } from 'react';
import { useState } from 'react';

const theme = createTheme();

export default function SignUp() {
  const [nameError, setnameError] = useState();
  const [usernameError, setUsernameError] = useState();
  const [passwordError, setPasswordError] = useState();
  const [roleError, setRoleError] = useState();
  const [role, setRole] = useState('')
  const navigate = useNavigate()

  // Redirect if someone is already logged in
  const token = localStorage.getItem('token')
  useEffect(() => {
    if (token) {
      return navigate('/dashboard')
    }
  }, [])
  const handleRoleChange = (event) => {
    setRole(event.target.value)
    console.log(event.target.value);
  }

  const validation = (userData) => {
    let isValid = true;

    if (userData.name.trim() === '') {
      setnameError('Name is required')
      isValid = false;
    } else {
      setnameError('')
    }

    if (userData.username.trim() === '') {
      setUsernameError('UserName is required')
      isValid = false;
    } else {
      setUsernameError('')
    }

    if (userData.password.trim() === '') {
      setPasswordError('Password is required')
      isValid = false;
    } else {
      setPasswordError('')
    }

    if (userData.role.trim() === '') {
      setRoleError('Role is required')
      isValid = false;
    } else {
      setRoleError('')
    }

    return isValid;
  }


  const handleSubmit = async (event) => {
    event.preventDefault();


    const data = new FormData(event.currentTarget);

    const userObj = {
      name: data.get('name'),
      username: data.get('username'),
      password: data.get('password'), 
      role: role
    }
    // console.log(userObj);
    if (validation(userObj)) {
      const result = await apiService.createUser(userObj)
      console.log('created user', result)

      // const loginResult = await apiService.login(userObj)
      // localStorage.setItem('token', loginResult.token)
      navigate('/login')
    }

  };


  return (
    <ThemeProvider theme={theme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >
          <Typography component="h1" variant="h5">
            Sign up
          </Typography>
          <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  autoComplete="given-name"
                  name="name"
                  required
                  fullWidth
                  id="name"
                  label="Name"
                  error={!!nameError}
                  autoFocus
                />
                {nameError && <Typography variant="caption" color="error">{nameError}</Typography>}
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="username"
                  label="Username"
                  name="username"
                  error={!!usernameError}
                  autoComplete="username"
                />
                {usernameError && <Typography variant="caption" color="error">{usernameError}</Typography>}
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  type="password"
                  error={!!passwordError}
                  id="password"
                  autoComplete="new-password"
                />
                {passwordError && <Typography variant="caption" color="error">{passwordError}</Typography>}

              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth required id="role" >
                  <InputLabel id="role-label">Role</InputLabel>
                  <Select
                    labelId="role-label"
                    label="Role"
                    id="role"
                    value={role}
                    onChange={handleRoleChange}
                    error={!!roleError}
                  >
                    <MenuItem value="developer">Developer</MenuItem>
                    <MenuItem value="admin">Admin</MenuItem>
                  </Select>
                  {roleError && <Typography variant="caption" color="error">{roleError}</Typography>}
                </FormControl>
              </Grid>
            </Grid>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign Up
            </Button>
          </Box>

          <Link to="/login">Already have an account? Click here to log in</Link>
        </Box>
      </Container>
    </ThemeProvider>
  );
}